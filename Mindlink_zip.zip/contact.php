<?php
use PHPMailer\PHPMailer\PHPMailer;
require 'autoload.php';
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.hostinger.com';
    $mail->Port = 587;
    $mail->SMTPAuth = true;
    $mail->Username = 'admin@kulalarmarriage.com';
    $mail->Password = 'maams2019';
    $mail->setFrom('admin@kulalarmarriage.com', 'URGENT_Mindlink_Enquiry');
    $mail->addAddress('mindlinkcontactus@kulalarmarriage.com', 'mindlinkcontactus');
    if (isset($_POST['name'])) {
            $name = $_POST['name'];
        }

    if (isset($_POST['email'])) {
            $email = $_POST['email'];
        }     

    if ($mail->addReplyTo($_POST['email'], $_POST['name'])) {
        $mail->Subject = 'Mindlink website Contact form ';
        $mail->isHTML(false);
        $mail->Body = <<<EOT
        Email: {$_POST['email']}
        Name: {$_POST['name']}
        Message: {$_POST['message']}
        Phone: {$_POST['phone']}
EOT;
        if (!$mail->send()) {
            $msg = 'Sorry, something went wrong. Please try again later.';
        } else {
            $msg = 'We received your message. We will get back to you at the earliest.';
        }
    } else {
        $msg = 'Invalid email address, message ignored.';
    }


?>







<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
       <meta name="Description" content="mindlink technologies,
    mindlink.in, mindlink india,arjun infotech inc, ait-techcorp
    Professional services and business consulting corporation, Connecting brilliant minds to build the future, digital marketing salem, digital marketing india, SEO salem, SEO India,EVERYTHING YOU NEED TO DIGITAL MARKET YOUR WEBSITE ">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>MINDLINK TECHNOLOGIES</title>
    <link rel="icon" href="img/fav.png" type="image/x-icon">

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="ionicons/css/ionicons.min.css" rel="stylesheet">

    <!-- main css -->
    <link href="css/style.css" rel="stylesheet">


    <!-- modernizr -->
    <script src="js/modernizr.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>

    <!-- Preloader -->
    <div id="preloader">
        <div class="pre-container">
            <div class="spinner">
                <div class="double-bounce1"></div>
                <div class="double-bounce2"></div>
            </div>
        </div>
    </div>
    <!-- end Preloader -->

    <div class="container-fluid">
        <!-- box header -->
        <header class="box-header">
            <div class="box-logo">
                <a href="index.html"><img src="img/logo.png" width="80" alt="Logo"></a>
            </div>
            <!-- box-nav -->
            <a class="box-primary-nav-trigger" href="#0">
                <span class="box-menu-text">Menu</span><span class="box-menu-icon"></span>
            </a>
            <!-- box-primary-nav-trigger -->
        </header>
        <!-- end box header -->

        <!-- nav -->
        <nav>
            <ul class="box-primary-nav">
                <li class="box-label">Menu</li>

                <li><a href="index.html">Home</a> 
                <li><a href="FamilyWebsite.html">Family Website</a></li>
                <li><a href="Ecomwebsite.html">E-commerce website</a></li>
                <li><a href="FloatingResume.html">Floating Resume</a></li>
                <li><a href="DigitalMarketing.html">Digital Marketing</a></li>
                <li><a href="Mobiledevices.html">Mobile devices</a></li>
                <li><a href="seo.html">SEO</a></li>
                <li><a href="security.html">Security</a></li>
                <li><a href="jobs.html">Jobs</a></li>
                <li><a href="contact.html">Contact us</a><i class="ion-ios-circle-filled color"></i></li>
                <li><a href="about.html">About MINDLINK</a></li>


              <!--  <li class="box-label">Follow me</li>

                <li class="box-social"><a href="#0"><i class="ion-social-facebook"></i></a></li>
                <li class="box-social"><a href="#0"><i class="ion-social-instagram-outline"></i></a></li>
                <li class="box-social"><a href="#0"><i class="ion-social-twitter"></i></a></li>
                <li class="box-social"><a href="#0"><i class="ion-social-dribbble"></i></a></li>-->
            </ul>
        </nav>
        <!-- end nav -->

    </div>

    <!-- top bar -->
    <div class="top-bar">
        <h1>contact us</h1>
        <p>We are here to help</p>
    </div>
    <!-- end top bar -->

    <!-- main-container -->
   
    <div class="container main-container">
        <div class="col-md-6">
            <form method="post">
                 <?php if(isset($email)){
              echo 'Success! Thanks for submitting';
              } ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="input-contact">
                            <input type="text" name="name">
                            <span>your name</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="input-contact">
                            <input type="text" name="email">
                            <span>your email</span>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="input-contact">
                            <input type="text" name="phone">
                            <span>Phone number</span>
                        </div>
                    </div>
            
                    <div class="col-md-12">
                        <div class="textarea-contact">
                            <textarea name="message"></textarea>
                            <span>message</span>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <!--<a href="#" class="btn btn-box">Send</a>-->
                        <input type="submit" value="Send">
                    </div>
                </div>
            </form>
        </div> 

        <div class="col-md-6">
            <h3 class="text-uppercase">Drop us a message </h3>
            <h5>Put your questions to words and contact us</h5>
            <div class="h-30"></div>
            <p>Please send us all the questions, enquires or service requests you have. Our team will get back to you at the earliest. If you are find one of the current job opening matching your profile please mail us at jobs@mindklink.in. </p>
            <div class="contact-info">
                <p><i class="ion-android-call"></i> +91 9894452523</p>
                <p><i class="ion-ios-email"></i> info@mindlink.in</p>
            </div>
        </div>
       

    </div>
    <!-- end main-container -->

    <!-- footer -->
    <footer>
        <div class="container-fluid">
            <p class="copyright">©MINDLINK.IN | 
            <i class="ion-android-call"></i> +91 9894452523 |
           <i class="ion-ios-email"></i> info@mindlink.in</p>
        </div>

    </footer>
    <!-- end footer -->

    <!-- back to top -->
    <a href="#0" class="cd-top"><i class="ion-android-arrow-up"></i></a>
    <!-- end back to top -->



    <!-- jQuery -->
    <script src="js/jquery-2.1.1.js"></script>
    <!--  plugins -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menu.js"></script>
    <script src="js/animated-headline.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>


    <!--  custom script -->
    <script src="js/custom.js"></script>

</body>

</html>